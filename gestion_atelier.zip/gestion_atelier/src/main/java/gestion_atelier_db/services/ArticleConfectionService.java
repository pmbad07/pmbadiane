package gestion_atelier_db.services;



import gestion_atelier_db.entities.ArticleConfection;


public interface ArticleConfectionService extends IService<ArticleConfection>  {
   
}
