package gestion_atelier_db.repositories.list;

import gestion_atelier_db.entities.ArticleConfection;

public class TableArticleConfections extends AbstractTables<ArticleConfection> {
    
}
