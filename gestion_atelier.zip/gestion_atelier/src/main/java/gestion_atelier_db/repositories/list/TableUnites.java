package gestion_atelier_db.repositories.list;

import gestion_atelier_db.entities.Unite;

public class TableUnites extends AbstractTables<Unite> {

 
}
