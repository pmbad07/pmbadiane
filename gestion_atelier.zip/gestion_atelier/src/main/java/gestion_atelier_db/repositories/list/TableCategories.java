package gestion_atelier_db.repositories.list;



import gestion_atelier_db.entities.Categorie;

public class TableCategories extends AbstractTables<Categorie> {

}


